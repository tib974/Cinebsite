# Règles — CinéB
- Explique chaque mot technique en 1 phrase simple (FR).
- Travaille **dans** `/Users/thibautapv/Desktop/Cinebsite`.
- Demande confirmation avant chaque commande système.
- Commentaires courts utiles dans le code.
- Priorité au gratuit (local, scripts, Actions).

Base: CinéB · “Le cinéma à La Réunion” · fr · Accueil/Catalogue/Contact · dégradé mauve→noir (#7E57C2 → #121212).

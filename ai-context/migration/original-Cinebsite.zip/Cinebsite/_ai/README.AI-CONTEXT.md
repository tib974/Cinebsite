# AI Context — v3 FULL+ (updated 2025-09-11)
Fixed: `/Users/thibautapv/Desktop/ai-context` · Project: `/Users/thibautapv/Desktop/Cinebsite` · Zed + Gemini CLI.

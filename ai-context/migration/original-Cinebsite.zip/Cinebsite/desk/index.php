<?php
// Simple alias: redirect /desk to /office
header('Location: ../office/login.php');
exit;


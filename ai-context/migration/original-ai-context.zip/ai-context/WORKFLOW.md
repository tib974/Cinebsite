# WORKFLOW — Comment reprendre facilement

## Si tu utilises ChatGPT, Perplexity, etc.
1) Ouvre **UNIVERSAL_PROMPT.txt** → copie tout → colle-le dans une nouvelle discussion.  
2) Dis : “Lis aussi CONTEXTE_GLOBAL.md et AGENT_MEMO_GEMINI.md si besoin”.  
3) Demande l’action du moment (ex. “Créer un mini-site et l’ouvrir en local”).

## Si tu utilises Continue.dev (VS Code)
1) Ouvre le chat Continue → colle **UNIVERSAL_PROMPT.txt**.  
2) Demande “Prépare les commandes exactes à lancer dans le terminal Mac pour créer mon projet X.”  
3) Copie les commandes proposées → colle-les **dans le Terminal** (ou dans l’onglet Terminal de VS Code).

## Si tu utilises Gemini CLI
1) Ouvre le **Terminal** et place-toi dans le dossier de travail (ou ce dossier).  
2) Tape `gemini` puis **colle** tout **UNIVERSAL_PROMPT.txt**.  
3) Colle ensuite ta demande (ex. “Prépare un script setup.sh qui installe X et lance Y”).

## Astuces
- Mets à jour **DECISIONS.md** après chaque choix important.  
- Note tes idées courtes dans **TODO.txt**.  
- Copie/colle des extraits de code ou d’erreur : l’IA te dira quoi faire ensuite.

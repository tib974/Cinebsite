# DECISIONS (journal des choix)
Créé le 2025-09-09. Complétez au fil du temps.

- [x] Choix de base : **Continue.dev + Gemini CLI** (gratuit/puissant).
- [ ] Éditeur principal : VS Code (OK) / Cursor (à tester) / Zed (à tester).
- [ ] Terminal : Apple Terminal (OK) / Warp (à tester pour confort).
- [ ] Hébergement : à décider (Netlify/Vercel/Fly/Render… priorité gratuit).
- [ ] Stack web : à décider (ex. Next.js + Tailwind).
- [ ] Base de données : à décider (SQLite pour débuter ?).

Ajoutez ici chaque décision importante, avec 1 phrase de “pourquoi”.

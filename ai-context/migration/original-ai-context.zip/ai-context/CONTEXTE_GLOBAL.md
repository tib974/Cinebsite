# CONTEXTE GLOBAL (résumé simple et fidèle)

Dernière mise à jour : 2025-09-09

## Objectif
Mettre en place un **“code agent”** (assistant qui code et automatise) **puissant mais presque gratuit**, pour créer des sites/apps
et automatiser des tâches (DevOps, scripts, scraping) **sans connaître le code**.

## Solution choisie (décision-clé)
**Combo : Continue.dev (dans VS Code) + Gemini CLI (terminal).**
- **Continue.dev** = confort d’édition dans VS Code (chat + génération + corrections).
- **Gemini CLI** = agent « plein pouvoir » dans le terminal (exécutions, automatisations, longues tâches).
- Principe : **Continue** pour écrire/éditer du code au calme; **CLI** pour les phases lourdes/automatisées.

## Contraintes et préférences
- Coût : **gratuit** ou **très peu cher** (priorité aux quotas gratuits).
- Interface : éviter le terminal brut quand c’est possible; préférer des explications **pas-à-pas**.
- Pédagogie : **zéro jargon** (ou jargon expliqué immédiatement).
- Plateforme : Mac (mais on donne des notes Windows quand utile).

## Quotas (règles simples à retenir)
- **Gemini Code Assist (VS Code)** : gratuit pour les particuliers → énormes complétions de code.
- **Gemini CLI via connexion Google (OAuth)** : **1 000 requêtes/jour** (et 60/min). Très généreux pour un usage perso.
- **API payante (si jamais)** : facturation « au volume de texte » (tokens). On l’évitera au maximum.

> Définitions rapides :  
> **Requête** = une question/ordre envoyé à l’IA.  
> **Token** = petit morceau de texte; plus on en envoie/reçoit, plus ça “coûte” en mode payant.

## Manière de travailler (workflow)
1. Décrire le besoin en langage simple (ex. “site vitrine 3 pages, formulaire de contact”).  
2. **Continue.dev** écrit le squelette, les fichiers, les tests, explique.  
3. **Gemini CLI** exécute les étapes longues (scripts, configuration, Docker, déploiement, scraping…).  
4. On alterne entre les deux selon la tâche (Confort/Édition ↔ Automatisation/Puissance).

## Style d’accompagnement attendu de l’IA
- Toujours expliquer les termes techniques en 1 phrase simple.  
- Donner des **instructions claires** “clic par clic” ou “copier-coller cette commande, ici”.  
- Proposer des **alternatives gratuites** si possible.  
- Avant une action risquée (ex. suppression), **demander confirmation**.

## Prochaines étapes (suggestion)
- Installer Continue.dev et Gemini CLI (voir WORKFLOW.md).  
- Créer un **premier mini-projet** pour valider la chaîne.  
- Ajouter vos notes ou décisions dans **DECISIONS.md**.

AI CONTEXT BUNDLE — Lisez-moi d’abord (version 2025-09-09)
======================================================

But de ce dossier
-----------------
Vous permettre de **reprendre votre réflexion là où vous l’avez laissée**, dans **n’importe quel outil d’IA**
(ChatGPT, Perplexity, Gemini Code Assist, Gemini CLI, etc.) — sans tout recommencer.

Comment l’utiliser (3 étapes ultra simples)
-------------------------------------------
1) Ouvrez le fichier **UNIVERSAL_PROMPT.txt** et copiez tout son contenu.
2) Collez-le au début de votre conversation dans l’outil d’IA que vous utilisez (ChatGPT, Perplexity, etc.).
3) Quand l’IA répond, si elle a besoin de plus de contexte, dites-lui : 
   « Lis aussi CONTEXTE_GLOBAL.md et AGENT_MEMO_GEMINI.md du dossier ai-context » 
   puis copiez/collez les sections utiles (ou joignez les fichiers si l’outil le permet).

Cas particuliers
----------------
• **Gemini CLI (terminal)** : ouvrez le terminal dans ce dossier, lancez `gemini`, puis **collez d’abord le contenu complet
  de UNIVERSAL_PROMPT.txt**. Ensuite, collez des morceaux de CONTEXTE_GLOBAL.md si besoin.
• **Continue.dev (dans VS Code)** : dans la première question au chat, **collez UNIVERSAL_PROMPT.txt**.
• **Perplexity Pro** : collez **UNIVERSAL_PROMPT.txt** dans un nouveau fil, puis demandez « lis aussi CONTEXTE_GLOBAL.md »
  (vous pouvez joindre/colller des extraits).

Astuce
------
Gardez ce dossier **à la racine de vos projets** (ou dans Documents/ai-context) et mettez-le à jour au fil des décisions.

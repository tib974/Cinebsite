#!/usr/bin/env bash
# Affiche le prompt universel dans le terminal pour faciliter le copier-coller.
cat "$(dirname "$0")/UNIVERSAL_PROMPT.txt"

# Routine du matin

1) Lance `/Users/thibautapv/Desktop/ai-context/scripts/start_workday.sh` (double‑clic ou Terminal).
2) Zed s’ouvre sur `/Users/thibautapv/Desktop/Cinebsite` + Terminal lance `g` (Gemini).
3) Le prompt 01 est déjà copié — colle (⌘V) dans Gemini.
4) Suis les commandes (ex. `./serve.sh` → http://localhost:8080).

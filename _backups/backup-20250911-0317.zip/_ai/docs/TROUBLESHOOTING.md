# Dépannage
- `GOOGLE_CLOUD_PROJECT` manquant → crée ~/.gemini/.env
- Ollama port déjà pris → serveur déjà lancé (curl 127.0.0.1:11434/api/version)
- Continue parse agent → config minimale

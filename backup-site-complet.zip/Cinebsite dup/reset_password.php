<?php
require_once __DIR__ . '/lib/config.php';
set_admin_password('cineb974');
echo "Le mot de passe a été réinitialisé avec succès.\n";
?>